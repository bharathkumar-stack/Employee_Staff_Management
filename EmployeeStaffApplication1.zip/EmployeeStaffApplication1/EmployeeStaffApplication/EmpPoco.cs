﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeStaffApplication
{
   public class EmpPoco
    {
        public int EmpId { get; set; }
        public String EmpName { get; set; }
        public String EmpPhone { get; set; }
        public String EmpGender { get; set; }
        public String EmpPosition { get; set; }
        public String EmpEducation { get; set; }
        public String EmpDob { get; set; }
        public String EmpAddress { get; set; }
        public String EmpLocation { get; set; }
        public String EmpPass { get; set; }
    }
}

﻿namespace EmployeeStaffApplication
{
    partial class numslip
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(numslip));
            this.label = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.numempworkindays = new System.Windows.Forms.NumericUpDown();
            this.numpayslip = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.btnfront = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.numsalary = new System.Windows.Forms.NumericUpDown();
            this.numpayslipid = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numempworkindays)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numpayslip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numsalary)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numpayslipid)).BeginInit();
            this.SuspendLayout();
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.BackColor = System.Drawing.SystemColors.Control;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label.Location = new System.Drawing.Point(269, 204);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(127, 29);
            this.label.TabIndex = 0;
            this.label.Text = "Payslip Id";
            this.label.Click += new System.EventHandler(this.label1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label5.Location = new System.Drawing.Point(259, 351);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(190, 29);
            this.label5.TabIndex = 0;
            this.label5.Text = "Provident Fund";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.Control;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label7.Location = new System.Drawing.Point(575, 204);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(297, 29);
            this.label7.TabIndex = 0;
            this.label7.Text = "Employee Working Days";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // numempworkindays
            // 
            this.numempworkindays.Location = new System.Drawing.Point(579, 243);
            this.numempworkindays.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numempworkindays.Name = "numempworkindays";
            this.numempworkindays.Size = new System.Drawing.Size(170, 22);
            this.numempworkindays.TabIndex = 1;
            // 
            // numpayslip
            // 
            this.numpayslip.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numpayslip.Location = new System.Drawing.Point(263, 394);
            this.numpayslip.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.numpayslip.Name = "numpayslip";
            this.numpayslip.Size = new System.Drawing.Size(186, 27);
            this.numpayslip.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.button1.Location = new System.Drawing.Point(1008, 442);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(124, 48);
            this.button1.TabIndex = 2;
            this.button1.Text = "Genereate";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnback
            // 
            this.btnback.Location = new System.Drawing.Point(2, 1);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(75, 34);
            this.btnback.TabIndex = 36;
            this.btnback.Text = "<-";
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Red;
            this.btnexit.Location = new System.Drawing.Point(1239, 1);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(34, 26);
            this.btnexit.TabIndex = 37;
            this.btnexit.Text = "X";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // btnfront
            // 
            this.btnfront.Location = new System.Drawing.Point(96, 1);
            this.btnfront.Name = "btnfront";
            this.btnfront.Size = new System.Drawing.Size(75, 34);
            this.btnfront.TabIndex = 35;
            this.btnfront.Text = "->";
            this.btnfront.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.button2.Location = new System.Drawing.Point(367, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(505, 55);
            this.button2.TabIndex = 2;
            this.button2.Text = "Generate Pay Slip";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label2.Location = new System.Drawing.Point(575, 351);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(210, 29);
            this.label2.TabIndex = 0;
            this.label2.Text = "Employee Salary";
            this.label2.Click += new System.EventHandler(this.label7_Click);
            // 
            // numsalary
            // 
            this.numsalary.Location = new System.Drawing.Point(579, 397);
            this.numsalary.Maximum = new decimal(new int[] {
            1874919424,
            2328306,
            0,
            0});
            this.numsalary.Name = "numsalary";
            this.numsalary.Size = new System.Drawing.Size(206, 22);
            this.numsalary.TabIndex = 1;
            // 
            // numpayslipid
            // 
            this.numpayslipid.Location = new System.Drawing.Point(263, 255);
            this.numpayslipid.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numpayslipid.Name = "numpayslipid";
            this.numpayslipid.Size = new System.Drawing.Size(169, 22);
            this.numpayslipid.TabIndex = 1;
            // 
            // numslip
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1272, 602);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnfront);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.numsalary);
            this.Controls.Add(this.numpayslipid);
            this.Controls.Add(this.numempworkindays);
            this.Controls.Add(this.numpayslip);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "numslip";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "payslip";
            this.Load += new System.EventHandler(this.payslip_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numempworkindays)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numpayslip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numsalary)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numpayslipid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown numempworkindays;
        private System.Windows.Forms.NumericUpDown numpayslip;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Button btnfront;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numsalary;
        private System.Windows.Forms.NumericUpDown numpayslipid;
    }
}
﻿namespace EmployeeStaffApplication
{
    partial class EmployeeShowPayslip
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeShowPayslip));
            this.btnback = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.panelemployee = new System.Windows.Forms.Panel();
            this.lblsaldeduc = new System.Windows.Forms.Label();
            this.lbltotlasal = new System.Windows.Forms.Label();
            this.lblleaves = new System.Windows.Forms.Label();
            this.lbltwd = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lblpf = new System.Windows.Forms.Label();
            this.lblewd = new System.Windows.Forms.Label();
            this.lblpayid = new System.Windows.Forms.Label();
            this.lblid = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblempleaves = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblworkingdays = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panelemployee.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnback
            // 
            this.btnback.Location = new System.Drawing.Point(0, 2);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(75, 34);
            this.btnback.TabIndex = 42;
            this.btnback.Text = "<-";
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Red;
            this.btnexit.Location = new System.Drawing.Point(1226, 2);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(45, 34);
            this.btnexit.TabIndex = 40;
            this.btnexit.Text = "X";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // panelemployee
            // 
            this.panelemployee.Controls.Add(this.lblsaldeduc);
            this.panelemployee.Controls.Add(this.lbltotlasal);
            this.panelemployee.Controls.Add(this.lblleaves);
            this.panelemployee.Controls.Add(this.lbltwd);
            this.panelemployee.Controls.Add(this.lblname);
            this.panelemployee.Controls.Add(this.lblpf);
            this.panelemployee.Controls.Add(this.lblewd);
            this.panelemployee.Controls.Add(this.lblpayid);
            this.panelemployee.Controls.Add(this.lblid);
            this.panelemployee.Controls.Add(this.label2);
            this.panelemployee.Controls.Add(this.label11);
            this.panelemployee.Controls.Add(this.label12);
            this.panelemployee.Controls.Add(this.lblempleaves);
            this.panelemployee.Controls.Add(this.label14);
            this.panelemployee.Controls.Add(this.lblworkingdays);
            this.panelemployee.Controls.Add(this.label16);
            this.panelemployee.Controls.Add(this.label17);
            this.panelemployee.Controls.Add(this.label18);
            this.panelemployee.Location = new System.Drawing.Point(130, 192);
            this.panelemployee.Name = "panelemployee";
            this.panelemployee.Size = new System.Drawing.Size(1022, 376);
            this.panelemployee.TabIndex = 39;
            this.panelemployee.Paint += new System.Windows.Forms.PaintEventHandler(this.panelemployee_Paint);
            // 
            // lblsaldeduc
            // 
            this.lblsaldeduc.AutoSize = true;
            this.lblsaldeduc.Location = new System.Drawing.Point(806, 260);
            this.lblsaldeduc.Name = "lblsaldeduc";
            this.lblsaldeduc.Size = new System.Drawing.Size(54, 17);
            this.lblsaldeduc.TabIndex = 5;
            this.lblsaldeduc.Text = "label19";
            // 
            // lbltotlasal
            // 
            this.lbltotlasal.AutoSize = true;
            this.lbltotlasal.Location = new System.Drawing.Point(557, 323);
            this.lbltotlasal.Name = "lbltotlasal";
            this.lbltotlasal.Size = new System.Drawing.Size(54, 17);
            this.lbltotlasal.TabIndex = 5;
            this.lbltotlasal.Text = "label19";
            // 
            // lblleaves
            // 
            this.lblleaves.AutoSize = true;
            this.lblleaves.Location = new System.Drawing.Point(806, 195);
            this.lblleaves.Name = "lblleaves";
            this.lblleaves.Size = new System.Drawing.Size(54, 17);
            this.lblleaves.TabIndex = 5;
            this.lblleaves.Text = "label19";
            // 
            // lbltwd
            // 
            this.lbltwd.AutoSize = true;
            this.lbltwd.Location = new System.Drawing.Point(806, 124);
            this.lbltwd.Name = "lbltwd";
            this.lbltwd.Size = new System.Drawing.Size(54, 17);
            this.lbltwd.TabIndex = 5;
            this.lbltwd.Text = "label19";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(806, 54);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(54, 17);
            this.lblname.TabIndex = 5;
            this.lblname.Text = "label19";
            // 
            // lblpf
            // 
            this.lblpf.AutoSize = true;
            this.lblpf.Location = new System.Drawing.Point(339, 260);
            this.lblpf.Name = "lblpf";
            this.lblpf.Size = new System.Drawing.Size(54, 17);
            this.lblpf.TabIndex = 5;
            this.lblpf.Text = "label19";
            // 
            // lblewd
            // 
            this.lblewd.AutoSize = true;
            this.lblewd.Location = new System.Drawing.Point(339, 195);
            this.lblewd.Name = "lblewd";
            this.lblewd.Size = new System.Drawing.Size(54, 17);
            this.lblewd.TabIndex = 5;
            this.lblewd.Text = "label19";
            // 
            // lblpayid
            // 
            this.lblpayid.AutoSize = true;
            this.lblpayid.Location = new System.Drawing.Point(339, 124);
            this.lblpayid.Name = "lblpayid";
            this.lblpayid.Size = new System.Drawing.Size(54, 17);
            this.lblpayid.TabIndex = 5;
            this.lblpayid.Text = "label19";
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.Location = new System.Drawing.Point(339, 54);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(54, 17);
            this.lblid.TabIndex = 5;
            this.lblid.Text = "label19";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(617, 260);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Salary Deductions";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(419, 323);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 17);
            this.label11.TabIndex = 4;
            this.label11.Text = "Total Salary";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(129, 260);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(104, 17);
            this.label12.TabIndex = 4;
            this.label12.Text = "Provident Fund";
            // 
            // lblempleaves
            // 
            this.lblempleaves.AutoSize = true;
            this.lblempleaves.Location = new System.Drawing.Point(617, 195);
            this.lblempleaves.Name = "lblempleaves";
            this.lblempleaves.Size = new System.Drawing.Size(120, 17);
            this.lblempleaves.TabIndex = 4;
            this.lblempleaves.Text = "Employee Leaves";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(617, 124);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(132, 17);
            this.label14.TabIndex = 4;
            this.label14.Text = "Total Working Days";
            // 
            // lblworkingdays
            // 
            this.lblworkingdays.AutoSize = true;
            this.lblworkingdays.Location = new System.Drawing.Point(129, 195);
            this.lblworkingdays.Name = "lblworkingdays";
            this.lblworkingdays.Size = new System.Drawing.Size(162, 17);
            this.lblworkingdays.TabIndex = 4;
            this.lblworkingdays.Text = "Employee Working Days";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(617, 54);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(111, 17);
            this.label16.TabIndex = 4;
            this.label16.Text = "Employee Name";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(139, 124);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 17);
            this.label17.TabIndex = 4;
            this.label17.Text = "PaySlip Id";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(129, 54);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(87, 17);
            this.label18.TabIndex = 4;
            this.label18.Text = "Employee ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(503, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 32);
            this.label1.TabIndex = 36;
            this.label1.Text = "Pay Slip Details";
            // 
            // EmployeeShowPayslip
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1272, 602);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.panelemployee);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EmployeeShowPayslip";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EmployeeShowPayslip";
            this.Load += new System.EventHandler(this.EmployeeShowPayslip_Load);
            this.panelemployee.ResumeLayout(false);
            this.panelemployee.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Panel panelemployee;
        private System.Windows.Forms.Label lbltotlasal;
        private System.Windows.Forms.Label lblleaves;
        private System.Windows.Forms.Label lbltwd;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblpf;
        private System.Windows.Forms.Label lblewd;
        private System.Windows.Forms.Label lblpayid;
        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblempleaves;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblworkingdays;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblsaldeduc;
        private System.Windows.Forms.Label label2;
    }
}
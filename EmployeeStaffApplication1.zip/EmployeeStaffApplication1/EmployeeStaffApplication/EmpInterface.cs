﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeStaffApplication
{
    public partial class EmpInterface : Form
    {
        public EmpInterface()
        {
            InitializeComponent();
        }

        private void btndetails_Click(object sender, EventArgs e)
        {
            EmployeeshowDetails s = new EmployeeshowDetails();
            s.Show();
            this.Hide();
        }

        private void btnpayslip_Click(object sender, EventArgs e)
        {
            EmployeeShowPayslip m = new EmployeeShowPayslip();
            m.Show();
            this.Hide();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            EmployeeLogin k = new EmployeeLogin();
            k.Show();
            this.Hide();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeStaffApplication
{
    class AdminPoco
    {
        public string AdminID { get; set; }
        public string AdminPass { get; set; }
    }
}

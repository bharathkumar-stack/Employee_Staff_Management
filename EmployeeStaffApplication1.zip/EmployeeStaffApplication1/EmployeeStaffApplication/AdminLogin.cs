﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeStaffApplication
{
    public partial class AdminLogin : Form
    {
        SqlConnection conn;
        public AdminLogin()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["emp"].ConnectionString);
        }

        private void AdminLogin_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                string sql = "select *from AdminTable where AdminUser= '" + txtadmin.Text + "'and AdminPassWord='" + txtadminpass.Text + "'";

                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    MessageBox.Show("SUCESSFULLY LOGIN");
                    Home op = new Home();
                    op.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("INVALID EMPLOYEE ID AND PASSWORD !!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            catch (Exception)
            {
                MessageBox.Show("EMPLOYEE ID SHOULD BE IN NUMBERS ONLE!!");
            }

            conn.Close();

            clearall();

        }
        private void clearall()
        {
            txtadmin.Text = "";
            txtadminpass.Text = "";
        }

        private void btnhide_Click(object sender, EventArgs e)
        {

            if (txtadminpass.PasswordChar == '\0')
            {
                btnunhide.BringToFront();
                txtadminpass.PasswordChar = '*';
            }
        }

        private void btnunhide_Click(object sender, EventArgs e)
        {
            if (txtadminpass.PasswordChar == '*')
            {
                btnhide.BringToFront();
                txtadminpass.PasswordChar = '\0';
            }
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            DashBoard dashboard = new DashBoard();
            dashboard.Show();
            this.Hide();
        }

        /* try
             {
                 conn.Open();
                 string query = "select * from AdminTable where AdminUser='" + txtadmin.Text + "' and AdminPassWord='" + txtadminpass.Text + "'";
                 SqlCommand cmd = new SqlCommand(query, conn);
                 SqlDataReader reader = cmd.ExecuteReader();
                 AdminPoco c = new AdminPoco();
                 if (reader.Read())
                     c.AdminID = reader[0].ToString();
                 c.AdminPass = reader[1].ToString();
                     if (txtadmin.Text== c.AdminID && txtadminpass.Text==c.AdminPass)
                     {
                         MessageBox.Show("Login Successful");
                         Home h = new Home();
                         h.Show();
                     }
                     else
                     {
                         MessageBox.Show("Check Username and password once again");
                     }
                 conn.Close();
             }
             catch (Exception ob)
             {
                 MessageBox.Show(ob.Message);
             }*/
    }
}
